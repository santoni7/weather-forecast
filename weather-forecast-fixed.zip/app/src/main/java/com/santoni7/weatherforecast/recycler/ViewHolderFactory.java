package com.santoni7.weatherforecast.recycler;

import android.view.ViewGroup;

public interface ViewHolderFactory {
    DailyViewHolder createViewHolder(ViewGroup parent);
}
