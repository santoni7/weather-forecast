# Weather Forecast
Android weather forecast application made for educational purposes.  
**Data from**: openweathermap.com  
**Weather icons**: https://erikflowers.github.io/weather-icons/  
## Screenshots:
![screenshot_2017-04-24-19-37-11](https://cloud.githubusercontent.com/assets/3082627/25348601/6edb5f90-2927-11e7-9012-baf6b34f7a4c.jpg)
![screenshot_2017-04-24-19-37-24](https://cloud.githubusercontent.com/assets/3082627/25348627/7fc5c80e-2927-11e7-9650-7080e0d74d91.jpg)
