package com.santoni7.weatherforecast.mvp;


public interface MvpView {
}
